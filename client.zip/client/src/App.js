import './App.css';
import Footer from './components/footer/Footer';
import Navbar from './components/header/Navbar';
import Maincomp from './components/home/Maincomp';
import Newnav from './components/newnavbaar/Newnav';
import Sign_in from './components/signup_signin/Sign_in';
import SignUp from './components/signup_signin/SignUp';
import {Routes, Route} from 'react-router-dom'
import Cart from './components/cart/Cart'
import Buynow from './components/buynow/Buynow';
function App() {
  return (
   <>
   <Navbar/>
   <Newnav/>
   <Routes>
     <Route path='/' element={<Maincomp/>}></Route>
     <Route path='/login' element={<Sign_in/>}></Route>
     <Route path='/register' element={<SignUp/>}></Route>
     <Route path='/getproductsone/:id' element={<Cart/>}></Route>
     <Route path='/buynow' element={<Buynow/>}></Route>
   </Routes>
   <Footer/>
   </>
  );
}

export default App;
