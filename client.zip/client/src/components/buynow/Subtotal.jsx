import React from 'react'

const Subtotal = () => {
  return (
    <div className='sub_item'>
        <h3>SubTotal (1 item): <strong style={{fontWeight:"700", color:"#111"}}>4090.00</strong></h3>
    </div>
  )
}

export default Subtotal