import React from 'react'
import { NavLink } from 'react-router-dom'
import { useState } from 'react'

const SignUp = () => {

    const [udata, setUdata] = useState({
        fname:"",
        email:"",
        mobile:"",
        password:"",
        cpassword:""
    })

    const adddata = (e)=>{
        const {name,value}=e.target;

        setUdata(()=>{
            return {
                ...udata,
                [name]:value
            }
        })
    }

  return (
    <div>
        <section>
                <div className="sign_container">
                    <div className="sign_header">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Amazon_logo.svg/1200px-Amazon_logo.svg.png" alt="amazon_logo" />
                    </div>
                    <div className="sign_form">
                        <form>
                            <h1>Create Account</h1>
                            <div className='form_data'>
                                <label htmlFor="fname">Your Name</label>
                                <input type="text"
                                onChange={adddata}
                                value={udata.fname}
                                name="fname" id="fname" placeholder='Your name' />
                            </div>
                            <div className='form_data'>
                                <label htmlFor="email">Email</label>
                                <input type="email"
                                onChange={adddata}
                                value={udata.email}
                                name="email" id="email" placeholder='Email' />
                            </div>

                            <div className='form_data'>
                                <label htmlFor="mobile">Mobile</label>
                                <input type="text"
                                onChange={adddata}
                                value={udata.mobile}
                                name="mobile" id="mobile" placeholder='mobile no' />
                            </div>

                            <div className='form_data'>
                                <label htmlFor="password">Password</label>
                                <input type="password"
                                onChange={adddata}
                                value={udata.password}
                                name="password" id="password" placeholder='At least 6 char' />
                            </div>
                            <div className='form_data'>
                                <label htmlFor="cpassword">Password Again</label>
                                <input type="password" name="cpassword" id="cpassword" />
                            </div>
                            <button className='signin_btn'>Continue</button>
                            <div className="signin_info">
                                <p>Already have an account</p>
                                <NavLink to="/login">Sign-In</NavLink>    
                            </div>
                        </form>
                    </div>
                </div>
            </section>
    </div>
  )
}

export default SignUp