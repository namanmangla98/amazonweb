import React from 'react'
import './newnav.css'


const Newnav = () => {
  return (
    <div>
        <div className="new_nav">
            <div className="nav_data">
                <div className="left_data">
                    <p>All</p>
                    <p>Mobile</p>
                    <p>BestSeller</p>
                    <p>Fashion</p>
                    <p>Customer Services</p>
                    <p>Electronics</p>
                    <p>Prime</p>
                    <p>Today's deal</p>
                    <p>Amazon pay</p>
                </div>
                <div className="right_data">
                    <img src="https://m.media-amazon.com/images/W/WEBP_402378-T2/images/G/31/AmazonVideo/2021/X-site/SingleTitle/RamSetu-SVOD/400x39-SWM_NP._CB617699705_.jpg" alt="" />
                </div>    
            </div>  
        </div>
    </div>
  )
}

export default Newnav
