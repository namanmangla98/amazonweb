import React from 'react'
import Carousel from 'react-material-ui-carousel'
import './banner.css'
// https://m.media-amazon.com/images/W/WEBP_402378-T2/images/I/71vdTR50hFL._SX3000_.jpg
// https://m.media-amazon.com/images/W/WEBP_402378-T2/images/I/61vFLT7BkDL._SX3000_.jpg
// https://m.media-amazon.com/images/I/61GnAucagBL._SX3000_.png
// https://m.media-amazon.com/images/W/WEBP_402378-T2/images/I/613-gA49v1L._SX3000_.jpg

const data =[
    "https://m.media-amazon.com/images/W/WEBP_402378-T2/images/I/71vdTR50hFL._SX3000_.jpg",
    "https://m.media-amazon.com/images/W/WEBP_402378-T2/images/I/61vFLT7BkDL._SX3000_.jpg",
    "https://m.media-amazon.com/images/I/61GnAucagBL._SX3000_.png",
    "https://m.media-amazon.com/images/W/WEBP_402378-T2/images/I/613-gA49v1L._SX3000_.jpg"
]

const Banner = () => {
  return (
      <>
    <Carousel  className="carasousel"
    autoPlay={true}
    animation="slide"
    indicators={false}
    navButtonsAlwaysVisible={true}
    cycleNavigation={true}
    navButtonsProps={{
        style: {
            background: "#fff",
            color: "#494949",
            borderRadius: 0,
            marginTop: -22,
            height: "104px",
        }
    }}>
        {
            data.map((imag,i)=>{
                return (
                    <>
                        <img src={imag} alt="" key={i} className='banner_img' />
                    </>
                )
            })
        }
    </Carousel>
    </>
  )
}

export default Banner